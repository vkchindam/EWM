sap.ui.define([
	"wp/inbound/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
